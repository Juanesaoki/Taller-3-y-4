package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public class CalculadoraTarifasTemporadaBaja extends CalculadoraTarifas {
	protected  int COSTOPORKMNATURAL= 600;
	protected  int COSTOPORKMCORPORATIVO= 900;
	protected  double Descuentopeq= 0.02;
	protected  double DescuentoMEDIANA= 0.1;
	protected  double DescuentoGRANDES= 0.2;
	

	@Override
	protected int CalcularCostoBase(Vuelo vuelo, Cliente cliente) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	protected double CalcularPorcentajeDescuento(Cliente cliente) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
