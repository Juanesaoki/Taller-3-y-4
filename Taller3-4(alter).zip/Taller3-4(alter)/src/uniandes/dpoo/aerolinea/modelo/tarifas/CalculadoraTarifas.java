package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public  abstract class CalculadoraTarifas {
	public double IMPUESTO= 0.28;
	protected int calcularTarifa(Vuelo vuelo,Cliente cliente) {return 1 ;}
	protected abstract int CalcularCostoBase(Vuelo vuelo,Cliente cliente);
	protected abstract double CalcularPorcentajeDescuento(Cliente cliente);
	protected  int  CalcularDistaciaVuelo(Ruta ruta){return 1 ;}
	protected int CalcularValorImpuestos(int costoBase) {return 1 ;}
	
	
	

}
