package uniandes.dpoo.aerolinea.modelo.cliente;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public  abstract class Cliente {
	
	public Cliente() {
		
	}
	public abstract String getTipoCliente();
	
	public abstract String getTipoIdentificador();
	public  abstract void  agregarTiquete(Tiquete tiquete);
	public abstract int calcularValorTotal();
	public abstract void usarTiquetes(Vuelo vuelo);
}
