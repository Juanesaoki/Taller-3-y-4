package uniandes.dpoo.aerolinea.modelo.cliente;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class ClienteNatural extends Cliente{
	
	    public String NATURAL = "Natural";
	    private String nombre;


	    public ClienteNatural(String nombre)
	    {
	        this.nombre = nombre;
	    }
	    public String getIdentificador()
	    {
	        return null;
	    }
	    public String getTipoCliente()
	    {
	        return null;
	    }
		@Override
		public String getTipoIdentificador() {
			// TODO Auto-generated method stub
			return null;
		}
		@Override
		public void agregarTiquete(Tiquete tiquete) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public int calcularValorTotal() {
			// TODO Auto-generated method stub
			return 0;
		}
		@Override
		public void usarTiquetes(Vuelo vuelo) {
			// TODO Auto-generated method stub
			
		}
	
}